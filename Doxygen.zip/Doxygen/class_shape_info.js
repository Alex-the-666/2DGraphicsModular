var class_shape_info =
[
    [ "ShapeInfo", "class_shape_info.html#a04468df73df160b1facf23ed7bd0c4d0", null ],
    [ "~ShapeInfo", "class_shape_info.html#a482564ea7679f40d46e55a8278aaf249", null ],
    [ "onTreeWidgetItemDoubleClicked", "class_shape_info.html#a6be2ea23536829cc1c8df73e3f22c55c", null ],
    [ "brush", "class_shape_info.html#a15675634bd81cbc5adde1b4ef025c24d", null ],
    [ "pen", "class_shape_info.html#ab9410c004accfb6a3aee8444401b7e66", null ],
    [ "ui", "class_shape_info.html#ac3b300e19e334254832f205250f06750", null ]
];