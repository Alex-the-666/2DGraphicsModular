var namespaces_dup =
[
    [ "custom", "namespacecustom.html", null ],
    [ "Ui", "namespace_ui.html", null ]
];