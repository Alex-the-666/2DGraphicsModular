var searchData=
[
  ['square',['SQUARE',['../shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345a4233fbf0cafb86abcee94b38d769fc59',1,'shapebuffer.h']]]
];
