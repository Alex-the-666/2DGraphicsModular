var searchData=
[
  ['ellipse',['ELLIPSE',['../shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345a59c6b7739f239fb18fe5c81692358893',1,'shapebuffer.h']]]
];
