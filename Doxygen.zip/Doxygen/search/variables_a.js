var searchData=
[
  ['painter',['painter',['../class_shape.html#a58a81e84552efaa9416f4179c8e2b615',1,'Shape']]],
  ['palette',['palette',['../class_main_window.html#a4d9eb17cd38c710447501315808a54e6',1,'MainWindow']]],
  ['pen',['pen',['../class_shape.html#a75d192b68eddd2622bdea8a4ac1058d1',1,'Shape::pen()'],['../class_shape_buffer.html#a09cc05eaf4341f03b9b1d319c6e0bd30',1,'ShapeBuffer::pen()'],['../class_shape_info.html#ab9410c004accfb6a3aee8444401b7e66',1,'ShapeInfo::pen()']]],
  ['polygon',['polygon',['../class_polygon.html#ab54c938e7706ab1a558925c974fda5e5',1,'Polygon']]]
];
