var searchData=
[
  ['ui',['Ui',['../namespace_ui.html',1,'Ui'],['../classadmin_login.html#aab376581a139361f605ed079c55fdc5e',1,'adminLogin::ui()'],['../class_contact.html#a723a93d653c3d19a5f9f2488dd4d5763',1,'Contact::ui()'],['../class_main_window.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow::ui()'],['../class_palette.html#a9dfe8d8a3609875b6b2c937798f2fbef',1,'Palette::ui()'],['../class_shape_info.html#ac3b300e19e334254832f205250f06750',1,'ShapeInfo::ui()']]],
  ['updatebackground',['updateBackground',['../class_palette.html#ae3f96a50e722da3391f40332766d54ae',1,'Palette']]]
];
