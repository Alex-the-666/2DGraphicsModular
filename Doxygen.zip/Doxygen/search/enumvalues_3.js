var searchData=
[
  ['polygon',['POLYGON',['../shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345ad5355465780b9a6259ebbc74d47477db',1,'shapebuffer.h']]],
  ['polyline',['POLYLINE',['../shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345a50a1f351acd916b6c96bb3ee91ada8f4',1,'shapebuffer.h']]]
];
