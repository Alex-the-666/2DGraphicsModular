var searchData=
[
  ['line',['Line',['../class_line.html#a239d3df65991a180d6d8c56b0e6b3720',1,'Line::Line()=delete'],['../class_line.html#adf5c469b18c312df186313fa031599e2',1,'Line::Line(const ShapeBuffer &amp;buffer)']]]
];
