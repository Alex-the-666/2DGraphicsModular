var searchData=
[
  ['radius1',['radius1',['../class_ellipse.html#a0703acd4407dbbee39b2880ce2f34535',1,'Ellipse']]],
  ['radius2',['radius2',['../class_ellipse.html#a9a9daac41a4bc8521fc754a654974826',1,'Ellipse']]],
  ['renderarea',['renderArea',['../class_main_window.html#a55c8e8eae9e774a691bc908420705f8f',1,'MainWindow']]]
];
