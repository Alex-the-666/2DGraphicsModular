var searchData=
[
  ['text',['Text',['../class_shape_buffer.html#aee0ad1dafe471596e6d25530d9fbaf0c',1,'ShapeBuffer']]]
];
