var searchData=
[
  ['x',['x',['../class_ellipse.html#a70771f8c320a2ae285a04fa97e808ff0',1,'Ellipse::x()'],['../class_rectangle.html#a7f6d033b3bb8dcf7bf8f82044592c904',1,'Rectangle::x()'],['../class_text.html#a0561058ba47e899900800635dbe270c2',1,'Text::x()']]]
];
