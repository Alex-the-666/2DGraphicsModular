var shapebuffer_8h =
[
    [ "MyException", "class_my_exception.html", null ],
    [ "ShapeBuffer", "class_shape_buffer.html", "class_shape_buffer" ],
    [ "ShapeType", "shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345", [
      [ "LINE", "shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345ab023460c84f774a219d46ccf4665994c", null ],
      [ "POLYLINE", "shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345a50a1f351acd916b6c96bb3ee91ada8f4", null ],
      [ "POLYGON", "shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345ad5355465780b9a6259ebbc74d47477db", null ],
      [ "RECTANGLE", "shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345ae552ab0a96c0384a6e918e726b7f6102", null ],
      [ "SQUARE", "shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345a4233fbf0cafb86abcee94b38d769fc59", null ],
      [ "ELLIPSE", "shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345a59c6b7739f239fb18fe5c81692358893", null ],
      [ "CIRCLE", "shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345aa79c827759ea48f0735386c4b1188911", null ],
      [ "TEXT", "shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345a9a4a47c1606e295076055a9cc4373197", null ]
    ] ]
];