var class_text =
[
    [ "Text", "class_text.html#ab3e26143fccc52699bcc5149cae852bc", null ],
    [ "Text", "class_text.html#a3a69628b67365dfc7c82a52274b3fb4a", null ],
    [ "~Text", "class_text.html#a4e7641708dfbf9c6bbbd41e897e9139c", null ],
    [ "area", "class_text.html#a7258b84057ebc36e530e04884b847565", null ],
    [ "draw", "class_text.html#aad1b04922d9ad2db31d0e398c6db39cd", null ],
    [ "draw", "class_text.html#a8f486a54a21fafc7a5dfb75975f1621f", null ],
    [ "move", "class_text.html#a36ddf5f82ee7ddfaf4a1d5ced6713d13", null ],
    [ "perimeter", "class_text.html#a0df4d872c788b58ca7fd1acd0cee9120", null ],
    [ "setShapeBuffer", "class_text.html#a1585c7c39cd56311c159a59a06fcfb70", null ],
    [ "alignFlag", "class_text.html#a026cd37255fd67a5b9215101f0bf614c", null ],
    [ "font", "class_text.html#aafbc87056bd5a3250299f2459078bf67", null ],
    [ "myQString", "class_text.html#abd7134c1f1307f663bef9a5f1dd2ab30", null ],
    [ "myRect", "class_text.html#a0312fcf77b6c419e072266094c82bc11", null ],
    [ "tall", "class_text.html#a882ee4f98cfff02aaa1a18f4b8f49f90", null ],
    [ "wide", "class_text.html#a7813ae637267fbae03d9c976cc375874", null ],
    [ "x", "class_text.html#a0561058ba47e899900800635dbe270c2", null ],
    [ "y", "class_text.html#a90f1e6cb7aa15a593d36c96144087179", null ]
];