var class_ellipse =
[
    [ "Ellipse", "class_ellipse.html#accf71158661908390b844fe673a60a2e", null ],
    [ "Ellipse", "class_ellipse.html#addff093b060f5e09e223eea74ecb58e3", null ],
    [ "~Ellipse", "class_ellipse.html#af7b546b29a2f8ce3494f9d02143a621c", null ],
    [ "area", "class_ellipse.html#add2f8178b1f6ee1ff53158730575d687", null ],
    [ "draw", "class_ellipse.html#a59cac1130e2dba94d118ae19d063a910", null ],
    [ "draw", "class_ellipse.html#ad55dcac6cfd2fa760d6dac54116f4f42", null ],
    [ "move", "class_ellipse.html#aa9b7011e1c80476201b7e24cb4c9918d", null ],
    [ "perimeter", "class_ellipse.html#af9680b6552fd6d941dabb329075753f1", null ],
    [ "setDimension", "class_ellipse.html#a44ca3233195bbaba46b128711c32e9d0", null ],
    [ "myRect", "class_ellipse.html#aaf2416ec4f9422cb7e8a64188f0a5fae", null ],
    [ "radius1", "class_ellipse.html#a0703acd4407dbbee39b2880ce2f34535", null ],
    [ "radius2", "class_ellipse.html#a9a9daac41a4bc8521fc754a654974826", null ],
    [ "x", "class_ellipse.html#a70771f8c320a2ae285a04fa97e808ff0", null ],
    [ "y", "class_ellipse.html#a37ca7f50a9df28e00428077cc1a38a3a", null ]
];