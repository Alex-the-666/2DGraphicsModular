var indexSectionsWithContent =
{
  0: "_abcdefghilmopqrstuvwxy~",
  1: "acelmprstv",
  2: "cu",
  3: "acelmprstv",
  4: "abcdegilmoprstuv~",
  5: "_abcefhimopqrstuwxy",
  6: "ci",
  7: "s",
  8: "celprst",
  9: "s",
  10: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Pages"
};

