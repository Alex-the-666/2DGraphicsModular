var searchData=
[
  ['text',['Text',['../class_text.html#a4ff8e50cb6adb1e5ed61aa619a49b9f5',1,'Text::Text()=delete'],['../class_text.html#a3a69628b67365dfc7c82a52274b3fb4a',1,'Text::Text(const ShapeBuffer &amp;arg)']]],
  ['timedifference',['timeDifference',['../class_main_window.html#a9b42d2070f5a350a3bafdaf68d817edb',1,'MainWindow']]],
  ['timerevent',['timerEvent',['../class_main_window.html#aaa425b1554af3c1f58cc70b4815082ae',1,'MainWindow']]],
  ['transfertoshapes',['transferToShapes',['../class_render_area.html#af3b9cb387049e30aae2f5879f837d0dc',1,'RenderArea']]]
];
