var searchData=
[
  ['initialtime',['initialTime',['../class_main_window.html#a76e5ee6e9b2fc14d0d0741abc113531d',1,'MainWindow']]]
];
