var searchData=
[
  ['tall',['tall',['../class_text.html#a882ee4f98cfff02aaa1a18f4b8f49f90',1,'Text']]],
  ['testvalue',['testValue',['../class_render_area.html#a87e4401f7cc663b2c25f0bc53ac9871a',1,'RenderArea']]],
  ['two',['two',['../class_line.html#a1e9ad57724dd2e3df5b1308801d6c312',1,'Line::two()'],['../class_shape_buffer.html#ac8e03e3d998b315384e152915a748538',1,'ShapeBuffer::two()']]]
];
