var annotated_dup =
[
    [ "custom", "namespacecustom.html", "namespacecustom" ],
    [ "adminLogin", "classadmin_login.html", "classadmin_login" ],
    [ "Circle", "class_circle.html", "class_circle" ],
    [ "compare_shape_perimeter", "classcompare__shape__perimeter.html", "classcompare__shape__perimeter" ],
    [ "Contact", "class_contact.html", "class_contact" ],
    [ "Ellipse", "class_ellipse.html", "class_ellipse" ],
    [ "Line", "class_line.html", "class_line" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "MyException", "class_my_exception.html", null ],
    [ "Palette", "class_palette.html", "class_palette" ],
    [ "Polygon", "class_polygon.html", "class_polygon" ],
    [ "PolyLine", "class_poly_line.html", "class_poly_line" ],
    [ "Rectangle", "class_rectangle.html", "class_rectangle" ],
    [ "RenderArea", "class_render_area.html", "class_render_area" ],
    [ "Shape", "class_shape.html", "class_shape" ],
    [ "ShapeBuffer", "class_shape_buffer.html", "class_shape_buffer" ],
    [ "ShapeInfo", "class_shape_info.html", "class_shape_info" ],
    [ "Square", "class_square.html", "class_square" ],
    [ "Text", "class_text.html", "class_text" ]
];