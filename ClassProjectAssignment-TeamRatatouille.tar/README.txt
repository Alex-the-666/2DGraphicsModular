The Deliverables for 2D Graphics Modular
Directory Listing
Deliverable 1) URL to GitHub repository. Please add JKATHSADDLEBACKEDU as a contributor to the repository.
            https://github.com/Alex-the-666/2DGraphicsModular

Deliverable 2) zip file containing complete Qt project. To include working UI 
            once project is opened and built in Qt.

Deliverable 3) zip file containing ONLY the class files written specifically 
            to satisfy project requirements. These classes are included in the 
            Qt front end UI project from step 2)

Deliverable 4) text file documenting which source files, line numbers from 
            step 3) satisfy individual project requirements (#1 thru #10) 
            and general project requirements (second paragraph of assignment). 
            For each project requirement include source file .h, .cpp name and relevant line numbers.

Deliverable 5) agile product backlog, scrum backlog and daily scrum meeting documentation for sprint #2

Deliverable 6) zip file containing doxygen class documentation

Deliverable 7) valgrind memory leak check

Deliverable 8) completed team project member contribution form. Each teammate must identify their accomplishments on the project

WE DID THE EXTRA CREDIT
Deliverable Extra Credit: Implement custom selections_sort algoritm - 
                        refer to selection_sort.h, though we did include in this tar file as well.