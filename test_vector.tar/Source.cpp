#include <iostream>
#include <string>
#include "vector_test.h"
using namespace std;

int main()
{
	test();
  return 0;
}

/*
#include <cassert>
int main()
{
  int num;
  cout << "Enter a number\n";
  cin >> num;
  
  assert(num != 0);// if  num!=0 continue, else assert
  cout << "Great! " <<num << endl;
  
  system("pause");
  return 0;
}
*/