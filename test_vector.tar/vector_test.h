#pragma once
#include "vector.h"
#include <iostream>
void test();