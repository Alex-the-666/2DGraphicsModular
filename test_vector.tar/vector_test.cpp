#include "vector_test.h"
void test()
{
	std::cout << "Starting vector test:\n";
	std::cout << "Creating new vector:\n";
	//system("pause");
	vector<int> *test_vector = new vector<int>(3);

	std::cout << "Populating new vector with  +33 elements:\n";
	for (int i = 0; i < 33; i++)
		test_vector->push_back(i);

	std::cout << "Resize to 4\n";
	test_vector->resize(4);

	std::cout << "Reserve to 400\n";
	test_vector->reserve(400);

	std::cout << "The capacity of the test_vector is: " << \
		test_vector->capacity() << std::endl;
	std::cout << "The size of the test_vector is: " << \
		test_vector->size() << std::endl;
	std::cout << "Elements in test_vector: ";
	for (vector<int>::iterator p = test_vector->begin(); p != test_vector->end(); p++)
		std::cout << *p << ' ';
	std::cout << std::endl;

	std::cout << "Inserting 43 at begin()+2\n";
	test_vector->insert((test_vector->begin()+2), 43);
	std::cout << "Erasing at begin()+1\n";
	test_vector->erase((test_vector->begin() + 1));

	std::cout << "Calling copy constructor\n";
	vector<int> *test_vector2 = new vector<int>(*test_vector);

	std::cout << "pushback() test_vector2 with  +33 elements:\n";
	for (int i = 0; i < 33; i++)
		test_vector2->push_back(i);

	std::cout << "Calling copy assignment test = test2\n";
	*test_vector = *test_vector2;

	std::cout << "Calling Move constructor from vector 1 to new vector 3\n.";
	vector<int> test_vector3 = std::move(*test_vector);

	std::cout << "Calling Move assignment vector 3 to vector 1\n";
	*test_vector = std::move(test_vector3);
	
	//system("pause");
	std::cout << "Delete 1st test vector\n";
	delete test_vector;
	test_vector = nullptr;
	std::cout << "Delete 2nd test vector\n";
	delete test_vector2;
	test_vector2 = nullptr;
	
	//system("pause");
}
