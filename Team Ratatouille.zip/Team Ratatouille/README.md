Open the index.html file in a browser to view Doxygen Documentation for Team Ratatouille.
Also included is UML Documentation.

Note: Does not work with Safari on Mac- use Chrome.