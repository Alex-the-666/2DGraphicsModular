Open the index.html file in a browser to view Doxygen Documentation for Team Ratatouille.

Note: Does not work with Safari on Mac- use Chrome.