var class_contact =
[
    [ "Contact", "class_contact.html#aafc8be61459240c18bb736fb6982f8ea", null ],
    [ "~Contact", "class_contact.html#ab68013cc59e3d640735c573e52c35219", null ],
    [ "ui", "class_contact.html#a723a93d653c3d19a5f9f2488dd4d5763", null ]
];