var searchData=
[
  ['contact',['contact',['../class_main_window.html#a9abab71bb4cf6ee27cb83b1733ef8edb',1,'MainWindow']]]
];
