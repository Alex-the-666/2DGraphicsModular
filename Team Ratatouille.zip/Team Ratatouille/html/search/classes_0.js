var searchData=
[
  ['adminlogin',['adminLogin',['../classadmin_login.html',1,'']]]
];
