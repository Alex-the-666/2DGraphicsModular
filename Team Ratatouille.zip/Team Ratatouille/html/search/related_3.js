var searchData=
[
  ['polygon',['Polygon',['../class_shape_buffer.html#a315fabe1f9025135d126119d96f7227e',1,'ShapeBuffer']]],
  ['polyline',['PolyLine',['../class_shape_buffer.html#a7aafcb68cf2c8ac2a6b41b5651307f19',1,'ShapeBuffer']]]
];
