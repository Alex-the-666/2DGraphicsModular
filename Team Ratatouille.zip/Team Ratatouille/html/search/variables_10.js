var searchData=
[
  ['wide',['wide',['../class_text.html#a7813ae637267fbae03d9c976cc375874',1,'Text']]],
  ['width',['width',['../class_rectangle.html#a019ed802523594472e0032953b6062d4',1,'Rectangle']]]
];
