var searchData=
[
  ['backgroundb',['backgroundB',['../class_palette.html#a04056dcb376ad5ee557d739c71124e6f',1,'Palette']]],
  ['backgroundg',['backgroundG',['../class_palette.html#aa77f1c515d6132ef86d6bf0a69423a56',1,'Palette']]],
  ['backgroundr',['backgroundR',['../class_palette.html#aff9d4a9a3d9c6f651f9a381ac2f3a55d',1,'Palette']]],
  ['begin',['begin',['../classcustom_1_1vector.html#a05d7f67d9f229fd1f4ded36403a8c24b',1,'custom::vector::begin()'],['../classcustom_1_1vector.html#adb7bd4241e5778c63446a484133d1ca2',1,'custom::vector::begin() const']]],
  ['brush',['brush',['../class_shape.html#aa67647c3a5d39d1e3f63a241208e59f2',1,'Shape::brush()'],['../class_shape_buffer.html#a8bc30f1ceec1edec1bdfe2ac35ad3042',1,'ShapeBuffer::brush()'],['../class_shape_info.html#a15675634bd81cbc5adde1b4ef025c24d',1,'ShapeInfo::brush()']]],
  ['buffer',['buffer',['../class_main_window.html#ae2e65b10fb1c9ca7eed6f61aad60b368',1,'MainWindow::buffer()'],['../class_render_area.html#aef05877d3007fcecdfc465285bc37b34',1,'RenderArea::buffer()']]]
];
