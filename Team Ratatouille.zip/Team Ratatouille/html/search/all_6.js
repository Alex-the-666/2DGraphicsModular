var searchData=
[
  ['font',['font',['../class_shape_buffer.html#a44089df16d24df2e68f1401285f94edb',1,'ShapeBuffer::font()'],['../class_text.html#aafbc87056bd5a3250299f2459078bf67',1,'Text::font()']]]
];
