var searchData=
[
  ['text',['TEXT',['../shapebuffer_8h.html#a5a4538eeab397888d88a4eefcc5a1345a9a4a47c1606e295076055a9cc4373197',1,'shapebuffer.h']]]
];
