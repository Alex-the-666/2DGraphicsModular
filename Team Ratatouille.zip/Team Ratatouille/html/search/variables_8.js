var searchData=
[
  ['myqstring',['myQString',['../class_text.html#abd7134c1f1307f663bef9a5f1dd2ab30',1,'Text']]],
  ['myrect',['myRect',['../class_ellipse.html#aaf2416ec4f9422cb7e8a64188f0a5fae',1,'Ellipse::myRect()'],['../class_text.html#a0312fcf77b6c419e072266094c82bc11',1,'Text::myRect()']]]
];
