var searchData=
[
  ['_5fx',['_x',['../class_square.html#ad381094376f3e704b5f21db473276a8b',1,'Square']]],
  ['_5fy',['_y',['../class_square.html#a128b2b3e8543856654d4119afef2771f',1,'Square']]]
];
