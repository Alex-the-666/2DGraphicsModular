var searchData=
[
  ['updatebackground',['updateBackground',['../class_palette.html#ae3f96a50e722da3391f40332766d54ae',1,'Palette']]]
];
