var searchData=
[
  ['admin',['admin',['../class_main_window.html#a798ab9f12ea8171528bb54dbc804dc5d',1,'MainWindow']]],
  ['alignflag',['alignFlag',['../class_shape_buffer.html#aa1214b50c58d085f97a349aaf540454c',1,'ShapeBuffer::alignFlag()'],['../class_text.html#a026cd37255fd67a5b9215101f0bf614c',1,'Text::alignFlag()']]]
];
