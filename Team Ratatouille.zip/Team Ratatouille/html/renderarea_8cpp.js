var renderarea_8cpp =
[
    [ "minSize", "renderarea_8cpp.html#a0ebe71ebee21e437e505d06ddb917337", null ]
];