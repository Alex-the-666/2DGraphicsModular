var files_dup =
[
    [ "adminlogin.cpp", "adminlogin_8cpp.html", null ],
    [ "adminlogin.h", "adminlogin_8h.html", [
      [ "adminLogin", "classadmin_login.html", "classadmin_login" ]
    ] ],
    [ "circle.cpp", "circle_8cpp.html", null ],
    [ "circle.h", "circle_8h.html", [
      [ "Circle", "class_circle.html", "class_circle" ]
    ] ],
    [ "contact.cpp", "contact_8cpp.html", null ],
    [ "contact.h", "contact_8h.html", [
      [ "Contact", "class_contact.html", "class_contact" ]
    ] ],
    [ "ellipse.cpp", "ellipse_8cpp.html", null ],
    [ "ellipse.h", "ellipse_8h.html", [
      [ "Ellipse", "class_ellipse.html", "class_ellipse" ]
    ] ],
    [ "line.cpp", "line_8cpp.html", null ],
    [ "line.h", "line_8h.html", [
      [ "Line", "class_line.html", "class_line" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", [
      [ "MainWindow", "class_main_window.html", "class_main_window" ]
    ] ],
    [ "palette.cpp", "palette_8cpp.html", null ],
    [ "palette.h", "palette_8h.html", [
      [ "Palette", "class_palette.html", "class_palette" ]
    ] ],
    [ "polygon.cpp", "polygon_8cpp.html", null ],
    [ "polygon.h", "polygon_8h.html", [
      [ "Polygon", "class_polygon.html", "class_polygon" ]
    ] ],
    [ "polyline.cpp", "polyline_8cpp.html", null ],
    [ "polyline.h", "polyline_8h.html", [
      [ "PolyLine", "class_poly_line.html", "class_poly_line" ]
    ] ],
    [ "rectangle.cpp", "rectangle_8cpp.html", null ],
    [ "rectangle.h", "rectangle_8h.html", [
      [ "Rectangle", "class_rectangle.html", "class_rectangle" ]
    ] ],
    [ "renderarea.cpp", "renderarea_8cpp.html", "renderarea_8cpp" ],
    [ "renderarea.h", "renderarea_8h.html", [
      [ "RenderArea", "class_render_area.html", "class_render_area" ]
    ] ],
    [ "selection_sort.h", "selection__sort_8h.html", "selection__sort_8h" ],
    [ "shape.cpp", "shape_8cpp.html", null ],
    [ "shape.h", "shape_8h.html", [
      [ "Shape", "class_shape.html", "class_shape" ]
    ] ],
    [ "shapebuffer.cpp", "shapebuffer_8cpp.html", null ],
    [ "shapebuffer.h", "shapebuffer_8h.html", "shapebuffer_8h" ],
    [ "shapeinfo.cpp", "shapeinfo_8cpp.html", null ],
    [ "shapeinfo.h", "shapeinfo_8h.html", [
      [ "ShapeInfo", "class_shape_info.html", "class_shape_info" ]
    ] ],
    [ "square.cpp", "square_8cpp.html", null ],
    [ "square.h", "square_8h.html", [
      [ "Square", "class_square.html", "class_square" ]
    ] ],
    [ "text.cpp", "text_8cpp.html", null ],
    [ "text.h", "text_8h.html", [
      [ "Text", "class_text.html", "class_text" ]
    ] ],
    [ "vector.h", "vector_8h.html", "vector_8h" ]
];