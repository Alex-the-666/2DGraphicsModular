var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a996c5a2b6f77944776856f08ec30858d", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "on_actionContact_Us_triggered", "class_main_window.html#a9eb26d6078b3b4cd61f1cb7fae386003", null ],
    [ "on_actionLogin_triggered", "class_main_window.html#a874e5c98f9db388d321421400e1a1c0d", null ],
    [ "on_actionOpen_palette_triggered", "class_main_window.html#aba6922bf3d1bf43bf07edf7fe207aa5a", null ],
    [ "on_actionOpen_triggered", "class_main_window.html#a48ed0a16f674e38e0e2a24274852a9af", null ],
    [ "on_actionQuit_triggered", "class_main_window.html#aa68eba140c2cf5c1cd2b4bd81337fa83", null ],
    [ "on_actionSave_triggered", "class_main_window.html#ad550c61cfa05c7e528dedc6cf636ed10", null ],
    [ "on_actionShow_Info_triggered", "class_main_window.html#af1b9c480aa504ca053cbe037b1140aaa", null ],
    [ "on_moveButton_clicked", "class_main_window.html#a39d312c7c24d8829c69fd36cf18df6c7", null ],
    [ "timeDifference", "class_main_window.html#a9b42d2070f5a350a3bafdaf68d817edb", null ],
    [ "timerEvent", "class_main_window.html#aaa425b1554af3c1f58cc70b4815082ae", null ],
    [ "admin", "class_main_window.html#a798ab9f12ea8171528bb54dbc804dc5d", null ],
    [ "buffer", "class_main_window.html#ae2e65b10fb1c9ca7eed6f61aad60b368", null ],
    [ "contact", "class_main_window.html#a9abab71bb4cf6ee27cb83b1733ef8edb", null ],
    [ "initialTime", "class_main_window.html#a76e5ee6e9b2fc14d0d0741abc113531d", null ],
    [ "palette", "class_main_window.html#a4d9eb17cd38c710447501315808a54e6", null ],
    [ "renderArea", "class_main_window.html#a55c8e8eae9e774a691bc908420705f8f", null ],
    [ "shapeInfo", "class_main_window.html#a3a52d14000c04146b3d84f48d2fddd4d", null ],
    [ "ui", "class_main_window.html#a35466a70ed47252a0191168126a352a5", null ]
];