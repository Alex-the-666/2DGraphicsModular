var class_shape_info =
[
    [ "ShapeInfo", "class_shape_info.html#a04468df73df160b1facf23ed7bd0c4d0", null ],
    [ "~ShapeInfo", "class_shape_info.html#a482564ea7679f40d46e55a8278aaf249", null ],
    [ "addTreeChild", "class_shape_info.html#a877a355092e4ee732df58b03d5d86682", null ],
    [ "addTreeRoot", "class_shape_info.html#aa3527ab36ff22e02543f6a911c192df9", null ],
    [ "brush", "class_shape_info.html#a15675634bd81cbc5adde1b4ef025c24d", null ],
    [ "pen", "class_shape_info.html#ab9410c004accfb6a3aee8444401b7e66", null ],
    [ "ui", "class_shape_info.html#ac3b300e19e334254832f205250f06750", null ]
];