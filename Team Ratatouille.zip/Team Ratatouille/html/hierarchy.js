var hierarchy =
[
    [ "compare_shape_perimeter< T >", "classcompare__shape__perimeter.html", null ],
    [ "MyException", "class_my_exception.html", null ],
    [ "QDialog", "class_q_dialog.html", [
      [ "adminLogin", "classadmin_login.html", null ],
      [ "Contact", "class_contact.html", null ],
      [ "Palette", "class_palette.html", null ],
      [ "ShapeInfo", "class_shape_info.html", null ]
    ] ],
    [ "QMainWindow", "class_q_main_window.html", [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QWidget", "class_q_widget.html", [
      [ "RenderArea", "class_render_area.html", null ]
    ] ],
    [ "Shape", "class_shape.html", [
      [ "Ellipse", "class_ellipse.html", [
        [ "Circle", "class_circle.html", null ]
      ] ],
      [ "Line", "class_line.html", null ],
      [ "Polygon", "class_polygon.html", null ],
      [ "PolyLine", "class_poly_line.html", null ],
      [ "Rectangle", "class_rectangle.html", null ],
      [ "Square", "class_square.html", null ],
      [ "Text", "class_text.html", null ]
    ] ],
    [ "ShapeBuffer", "class_shape_buffer.html", [
      [ "ShapeInfo", "class_shape_info.html", null ]
    ] ],
    [ "custom::vector< T >", "classcustom_1_1vector.html", null ],
    [ "custom::vector< Shape * >", "classcustom_1_1vector.html", null ],
    [ "custom::vector< ShapeBuffer >", "classcustom_1_1vector.html", null ]
];